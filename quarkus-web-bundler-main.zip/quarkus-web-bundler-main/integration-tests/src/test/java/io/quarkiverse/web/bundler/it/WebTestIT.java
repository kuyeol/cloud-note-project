package io.quarkiverse.web.bundler.it;

import io.quarkus.test.junit.QuarkusIntegrationTest;

@QuarkusIntegrationTest
public class WebTestIT extends WebTest {

    // Run the same tests

}
