import $ from 'jquery';

console.log($);
console.log("jefjnfejnefj")
