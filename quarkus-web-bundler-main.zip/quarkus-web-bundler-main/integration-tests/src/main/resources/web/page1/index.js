import './page1.js'
import '../app/styles/global.css'
import './page1.css'
import logo from './logo.jpg'

console.log(logo);