package io.quarkiverse.web.bundler.deployment.items;

import java.util.List;

public final class QuteTagsBuildItem extends WebAssetsBuildItem {

    public QuteTagsBuildItem(List<WebAsset> webAssets) {
        super(webAssets);
    }
}
