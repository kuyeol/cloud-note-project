package io.quarkiverse.web.bundler.deployment.items;

import java.util.List;

public final class StaticAssetsBuildItem extends WebAssetsBuildItem {

    public StaticAssetsBuildItem(List<WebAsset> webAssets) {
        super(webAssets);
    }
}
