package io.quarkiverse.web.bundler.deployment.items;

import java.util.List;

public final class StylesAssetsBuildItem extends WebAssetsBuildItem {

    public StylesAssetsBuildItem(List<WebAsset> webAssets) {
        super(webAssets);
    }
}
