package io.quarkiverse.web.bundler.deployment.items;

import java.util.List;

public final class BundleConfigAssetsBuildItem extends WebAssetsBuildItem {

    public BundleConfigAssetsBuildItem(List<WebAsset> webAssets) {
        super(webAssets);
    }
}
