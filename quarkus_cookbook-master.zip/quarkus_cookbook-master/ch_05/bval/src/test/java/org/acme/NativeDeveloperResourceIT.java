package org.acme;

import io.quarkus.test.junit.SubstrateTest;

@SubstrateTest
public class NativeDeveloperResourceIT extends DeveloperResourceTest {

    // Execute the same tests but in native mode.
}