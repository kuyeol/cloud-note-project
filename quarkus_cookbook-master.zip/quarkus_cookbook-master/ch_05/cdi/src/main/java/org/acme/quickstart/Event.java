package org.acme.quickstart;

public class Event {
    String methodName;
    String params;

    public Event(String methodName, String params) {
        this.methodName = methodName;
        this.params = params;
    }
}
