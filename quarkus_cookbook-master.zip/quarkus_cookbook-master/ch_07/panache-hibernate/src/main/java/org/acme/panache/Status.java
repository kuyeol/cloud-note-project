package org.acme.panache;

public enum Status {
    CHECKED_OUT,
    CHECKED_IN,
    ORDERED
}
