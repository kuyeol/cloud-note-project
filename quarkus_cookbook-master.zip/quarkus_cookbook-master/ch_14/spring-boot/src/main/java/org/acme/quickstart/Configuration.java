package org.acme.quickstart;

public class Configuration {

    private boolean uppercase;

    public boolean isUppercase() {
        return uppercase;
    }
    
    public void setUppercase(boolean uppercase) {
        this.uppercase = uppercase;
    }
}