package org.acme.quickstart;

/**
 * Transaction
 */
public class Transaction {

    public String from;
    public String to;
    public long amount;

}