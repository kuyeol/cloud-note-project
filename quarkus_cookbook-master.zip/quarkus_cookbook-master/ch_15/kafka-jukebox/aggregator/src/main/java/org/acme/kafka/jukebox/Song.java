package org.acme.kafka.jukebox;

public class Song {
    public int id;
    public String title;
    public String artist;
}
