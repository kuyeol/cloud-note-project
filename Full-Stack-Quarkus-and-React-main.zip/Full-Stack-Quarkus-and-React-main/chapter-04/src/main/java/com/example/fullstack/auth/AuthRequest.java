package com.example.fullstack.auth;

public record AuthRequest(String name, String password) {
}
