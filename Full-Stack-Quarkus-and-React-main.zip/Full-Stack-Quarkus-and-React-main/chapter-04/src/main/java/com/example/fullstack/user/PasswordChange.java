package com.example.fullstack.user;

public record PasswordChange(String currentPassword, String newPassword) {
}
