import {createTheme} from '@mui/material';

export const theme = createTheme({
  layout: {
    drawerWidth: 240,
  }
});
